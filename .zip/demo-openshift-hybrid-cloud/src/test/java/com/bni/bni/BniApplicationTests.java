package com.bni.bni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BniApplicationTests {

	@Test
	void contextLoads() {
	}

}
