package com.bni.bni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BniApplication {

	public static void main(String[] args) {
		SpringApplication.run(BniApplication.class, args);
	}

}
